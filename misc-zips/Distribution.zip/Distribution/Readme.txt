------------------------------------------------------------------------------------------------
YahCoLoRiZe supports the IceChat, LeafChat, and HydraIRC with the following plugins:
------------------------------------------------------------------------------------------------

ICECHAT

  http://www.yahcolorize.com/Plugins/IceChat/IceChatPlugin.zip

LEAFCHAT

  http://www.yahcolorize.com/Plugins/LeafChat/LeafChatPlugin.zip

HYDRAIRC

For HydraIRC I had to actually modify and rebuild the HydraIRC client and it's here,
complete with my plugin for YahCoLoRiZe:

  http://www.yahcolorize.com/Clients/HydraIRC.exe

My Hydra Plugin will not work with any other version of HydraIRC except the one above!

If the Hydra plugin gets updated, just the DLL file will be posted here:

  http://www.yahcolorize.com/Plugins/HydraIRC/HydraPlugin.zip

------------------------------------------------------------------------------------------------
YahCoLoRiZe supports the Vortec, XiRCON and mIRC IRC Clients with the following scripts:
------------------------------------------------------------------------------------------------
MIRC

For mIRC, enter the following in your aliases section:
(Old versions of mIRC should replace $1- with *1)

rem ***************************
rem NOTE: For some old versions of mIRC, replace $1- with *1 and replace
rem $left($lower($active),6) with $left(6,$lower($active)) - Cheers!
rem ***************************
rem Usage: /CPLAY <stop|start|pause|resume|filepath>
/cplay /dde colorize command ddeplay $1-
rem Usage: /CCHAN <New Channel To Set In YahCoLoRiZe>
/cchan /dde colorize command ddechan $1-
rem Usage: /CX <My Text To Process In YahCoLoRiZe>
cx {
if ($left($lower($active),6) == status) dde colorize command ddechan status
else dde colorize command ddechan $active
dde colorize command ddetext $1-
}

USAGE:
/cchan #NewChannel
/cplay stop|start|pause|resume|filepath
/cx Text to be processed

------------------------------------------------------------------------------------------------
VORTEC

For Vortec you can click the Aliases->"Add Script" button and locate the file:
C:\Program Files\Discrete-Time Systems\Colorize\colorize.ops

After import it will be in:
C:\Documents and Settings\<this computer user>\Application Data\Vortec IRC\Scripts\colorize.ops

Here is the script if you want to manually enter it (name it [COLORIZE]):

{
 Script:      [COLORIZE] for YahCoLoRiZe
 Author:      dxzl@live.com
 File:        colorize.ops
 Version:     7.0
 Vortec:      0.4.13 or higher
 YahCoLoRiZe: 5.70 or higher
 Usage:       Create alias CX: /runscript [colorize] $activewin *1
              Then in a chat window you type: /cx sometext

 This script is called by the CX alias. It sends text to YahCoLoRiZe
 where it is processed and returned to your chat-window :-)
}
var Wind,Parms: string;
begin
  Wind := $1; Parms := *2;
  Command('/ddepoke colorize command ddechan '+Wind);
  Command('/ddepoke colorize command ddevtext '+Parms);
end;

You also need to add these two aliases:

Name this one CCHAN:
/ddepoke colorize command ddechan *1

Name this one CX:
/runscript [colorize] $activewin *1

USAGE:
/cchan #NewChannel
/cx Text to be processed

------------------------------------------------------------------------------------------------
XIRCON

Copy colorize.tcl to the "C:\Program Files\XiRCON" directory (or to
"C:\Program Files (x86)\XiRCON" for 64-bit Windows).

Click the Tools->Preferences->Scripts tab and add "Colorize.tcl" and
"nocrash1.tcl" after "default.tcl"

Colorize.tcl is a Tcl-language script you load into your
XiRCON chat-client. The script loads Colorize.DLL.

!!!!IMPORTANT at the beginning of the script you need make
sure you are loading Colorize.dll from the proper path. On
64-bit machines Colorize.dll will be in "Program Files (x86)"
not "Program Files".

Here is the script just for reference:

# -----------------------------------------------------------------
# YahCoLoRiZe for GitHub by Scott Swift, Discrete-Time Systems Ver. 2.55

# IMPORTANT: Below, the path needs to be to the location of Colorize.dll
# on your system. On Windows 32-bit systems like XP uncomment the 1st line.
# On a 64-bit Windows system uncomment the second line.

load "/Program Files/Discrete-Time Systems/YahCoLoRiZe/Colorize.dll"
#load "/Program Files (x86)/Discrete-Time Systems/YahCoLoRiZe/Colorize.dll"

# Copy this file into your Program Files\XiRCON directory
# then add it to the scripts under Options->Scripts in XiRCON.
# Install YahCoLoRiZe (go to www.yahcolorize.com to download).
#
# Purpose: Allows the IRC Colorizer to talk to XiRCON through
# a DLL in order to play color text files into channels remotely.
# Since the DLL has all of the code required to play any text-file
# with high-resolution timing, I have added a scripting hook
# called DTS_play and an alais called "cplay" to access it.
#
# /cplay stop
# /cplay start
# /cplay pause
# /cplay resume
# /cplay <chan> <file> <time>
#
# Other commands (change YahCoLoRiZe chat-channel or send text for
# adding color:
# /cchan <chan>
# /cx <text>
#
# Normally, you would process and start playing a file from the controls
# of YahCoLoRiZe.  Then you could use "/cplay pause" etc. from XiRCON's
# command-line.
#
# A new command routes text from XiRCON to YahCoLoRiZe via Colorize.dll
# (/cx <text>). The text is processed and passed back to XiRCON into the
# currently set chat-channel.  Set the channel remotely on YahCoLoRiZe
# from XiRCON via the /cchan <channel> script command.
#
# E-mail: dxzl@live.com
# -----------------------------------------------------------------

# Custom TCL Script that works together with a custom DLL (Colorize.dll)
# for Colorize.exe (YahCoLoRiZe) to communicate with XiRCON

set othernick ""

# Alias added for XiRCON script writers
alias cplay {
  if { [llength [args]] == 1 } {
    if { ![stricmp [lindex [args] 0] "stop"] || ![stricmp [lindex [args] 0] "off"] } {
      DTS_play stop
    } elseif { ![stricmp [lindex [args] 0] "pause"] } {
      DTS_play pause
    } elseif { ![stricmp [lindex [args] 0] "resume"] } {
      DTS_play resume
    } elseif { ![stricmp [lindex [args] 0] "start"] } {
      DTS_play start
    } else {
      echo "*** USAGE: /CPLAY <start|stop|pause|resume> OR /CPLAY <channel> <file> <time in milliseconds>"
    }
  } elseif { [llength [args]] == 3 } {
    DTS_play [lindex [args] 0] [lindex [args] 1] [lindex [args] 2] false
  } else {
    echo "*** USAGE: /CPLAY <start|stop|pause|resume> OR /CPLAY <channel> <file> <time in milliseconds>"
  }
  complete
}

alias cx {
  set chan [string trim [channel]]
  set query [string trim [query]]
  set chat [string trim [chat]]
  if { [llength [args]] >= 1 } {
    if { $chan != "" } {
    DTS_chan $chan
	} elseif { $query != "" } {
    DTS_chan $query
	} elseif { $chat != "" } {
    DTS_chan $chat
	} else {
    DTS_chan "status"
	}
    DTS_ex [args]
  } else {
    echo "*** USAGE: /CX <text>"
  }
  complete
}

alias cchan {
  if { [llength [args]] == 1 } {
    DTS_chan [lindex [args] 0]
  } else {
    echo "*** USAGE: /CCHAN <chan>"
  }
  complete
}

#  Events  ###
on timer {
  if {[llength [info commands DTS_poll]]} { DTS_poll }
}
	
# General Procedures ###
proc stricmp { s1 s2 } {
    return [string compare [string tolower $s1] [string tolower $s2]]
}

Usage:
/cx text to send
/cx ## text to send (where ## of 00 is a random effect - 01, 02, etc are text-effects)
/cplay <stop|start|pause|resume>
/cplay <channel> <file> <time in milliseconds>



compile DefaultStrings.cpp for the language you want!
(there is only one DefaultStrings.h for all languages)